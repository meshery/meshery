See https://docs.meshery.io/project/releases
